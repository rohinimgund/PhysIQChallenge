package utility;

import java.io.File;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class testBase {
	private static WebDriver driver;
    
	public static WebDriver getDriver() {
		return driver;
	}
	public static void setDriver(WebDriver driver) {
		testBase.driver = driver;
	}

	public static void initialize() {
		System.setProperty("webdriver.chrome.driver", "src/test/resources/chromedriver");
        driver = new ChromeDriver();

        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().pageLoadTimeout(testUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(testUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);

	}
	
    public static void visitPge(String url)
    {   
    	initialize();
        driver.get(url);
    }

    public static void quit()
    {
        getDriver().quit();
    }
    
    public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{

    	//Convert web driver object to TakeScreenshot

        TakesScreenshot scrShot =((TakesScreenshot)webdriver);

        //Call getScreenshotAs method to create image file

        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

        //Move image file to new destination

        File DestFile=new File(fileWithPath);

        //Copy file at destination
        
        FileUtils.copyFile(SrcFile, DestFile);


    }
    
    public static void takeSnapShotOfForm(WebDriver webdriver,String fileWithPath) throws Exception{


        //Call getScreenshotAs method to create image file

                File SrcFile=driver.findElement(By.tagName("body")).getScreenshotAs(OutputType.FILE);

            //Move image file to new destination

                File DestFile=new File(fileWithPath);

                //Copy file at destination

                FileUtils.copyFile(SrcFile, DestFile);

    }
    
    public static void takeSnapShotUsingThirdParty(WebDriver webdriver,String fileWithPath) throws Exception{
    	
    	// capture screenshot and store the image
    	
        Screenshot s=new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(testBase.getDriver());
        
        ImageIO.write(s.getImage(),"PNG",new File(fileWithPath));
        

    }
}
