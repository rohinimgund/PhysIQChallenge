package utility;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;


public class testUtil {
	 static int PAGE_LOAD_TIMEOUT = 20;
	    static int IMPLICIT_WAIT = 30;
	    
	    public static void scrollDownPage(WebElement element) {
	    	JavascriptExecutor js = (JavascriptExecutor) testBase.getDriver();
	    	js.executeScript("arguments[0].scrollIntoView(true);", element);
	    }

}

