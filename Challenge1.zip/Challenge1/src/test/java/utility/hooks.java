package utility;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class hooks {
	
	@Before("@launch")
    public void launchBrowserAndLogin() throws Throwable{
        testBase.initialize();
    }	
	
	@After("@close")
    public void closeBrowser(){
		testBase.quit();
    }
}