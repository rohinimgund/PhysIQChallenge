package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import utility.testBase;

public class contactPage {
	
	public static String getTitle() {
		return testBase.getDriver().getTitle();
	}
	
	public static String mainOfficeAddressDetails() {
		return testBase.getDriver().findElement(By.xpath("//*[contains(text(),'MAIN OFFICE')]/following-sibling::p")).getText();
	}

	public static String napervilleOfficeAddressDetails() {
		return testBase.getDriver().findElement(By.xpath("//*[contains(text(),'NAPERVILLE OFFICE')]/following-sibling::p")).getText();
	}
	
	public static WebElement formForContactDetails() {
		return testBase.getDriver().findElement(By.xpath("//iframe[contains(@src,'form')]"));
	}
	
	public static WebElement InputField(String fieldName) {
		return testBase.getDriver().findElement(By.xpath("//li[contains(@class,'" +fieldName+"')]//input"));
	}
	
	public static WebElement InputTextAreaField(String fieldName) {
		return testBase.getDriver().findElement(By.xpath("//li[contains(@class,'" +fieldName+"')]//textarea"));
	}
	
	public static WebElement viewOpenPositions() {
		return testBase.getDriver().findElement(By.xpath("//*[contains(text(),'VIEW OPEN POSITIONS')]"));
	}

	public static void fillInForm(WebElement element,String input) {
		element.clear();
		element.sendKeys(input);
	}

}
