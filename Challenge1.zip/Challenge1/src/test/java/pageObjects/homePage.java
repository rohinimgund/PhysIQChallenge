package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import utility.testBase;

public class homePage {
	
	public static WebElement contactUsMenu() {
		return testBase.getDriver().findElement(By.xpath("//*[contains(@id,'navContactUs')]"));
	}
	
	public static void acceptCookies() {
		if(testBase.getDriver().findElement(By.xpath("//button[text()='ACCEPT']")).isDisplayed()) {
			testBase.getDriver().findElement(By.xpath("//button[text()='ACCEPT']")).click();
		}
	}
	

}
