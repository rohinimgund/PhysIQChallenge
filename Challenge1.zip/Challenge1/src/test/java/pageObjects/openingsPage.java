package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import utility.testBase;

public class openingsPage {

	public static WebElement getOpenPosition(String titleOpenPosition) {
		String openPosition = titleOpenPosition.toLowerCase().replace(" ", "-");
		return testBase.getDriver().findElement(By.xpath("//a[@href='/openings/"+openPosition+"' and @class='title']"));
	}
	
	public static WebElement readMoreOfOpenPosition(String titleOpenPosition) {
		String openPosition = titleOpenPosition.toLowerCase().replace(" ", "-");
		return testBase.getDriver().findElement(By.xpath("//a[@href='/openings/"+openPosition+"' and @class='btn']"));
	}
	
	public static WebElement jobDescription() {
		return testBase.getDriver().findElement(By.xpath("//*[contains(text(),'Job Description')]"));
	}

	public static WebElement openPositionDetails(String openPosition) {
		return testBase.getDriver().findElement(By.xpath("//*[contains(text(),'"+openPosition+"')]"));
	}
	
	public static WebElement mainSectionPage() {
		return testBase.getDriver().findElement(By.id("main-section"));
	}
	
}
