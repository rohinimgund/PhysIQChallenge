package stepDefinitions;

import org.junit.Assert;

import io.cucumber.java.en.Then;
import pageObjects.openingsPage;
import utility.testBase;
import utility.testUtil;

public class verifyContentOnOpeningsPage {
	@Then("^user should see Openings page$")
    public void user_should_see_Contact_page() throws Throwable {
    	String expectedTitle = "Visionaries Wanted to Join the physIQ Team - PhysIQ";
    	Assert.assertEquals(expectedTitle, testBase.getDriver().getTitle());
    }
	
	@Then("^user should see open position with name Inventory Specialist$")
    public void user_should_see_open_position_with_name_Inventory_Specialist() throws Throwable {
		testUtil.scrollDownPage(openingsPage.openPositionDetails("Inventory Specialist"));
    	Assert.assertTrue(openingsPage.getOpenPosition("Inventory Specialist").isDisplayed());
    }
	
	@Then("^read more about Inventory Specialist open position$")
    public void read_more_about_Inventory_Specialist_open_position() throws Throwable {
		testUtil.scrollDownPage(openingsPage.openPositionDetails("Inventory Specialist"));
    	openingsPage.readMoreOfOpenPosition("Inventory Specialist").click();
    	testUtil.scrollDownPage(openingsPage.jobDescription());
    }
	
	@Then("^take screenshot of job description details about open position$")
    public void take_screenshot_of_job_description_details_about_open_position() throws Throwable {
    	testBase.takeSnapShotOfForm(testBase.getDriver(), "src/test/resources/screenshots/OpenPositionDetails.png") ;
    	testBase.takeSnapShotUsingThirdParty(testBase.getDriver(), "src/test/resources/screenshots/OpenPositionDetailsFullPage.png");
		
    }

}
