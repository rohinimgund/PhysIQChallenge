package stepDefinitions;

import org.junit.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.contactPage;
import pageObjects.homePage;
import utility.testBase;

public class verifyContentOnContactUsPage {
	 	@Given("^user is on PhysIQ home page$")
	    public void user_is_on_PhysIQ_home_page() throws Throwable {
		 	testBase.visitPge("https://www.physiq.com/");
	    }
	    
	    @When("^user click on ContactUs menu$")
	    public void user_click_on_ContactUs_menu() throws Throwable {
	       homePage.acceptCookies();
	       homePage.contactUsMenu().click();
	    }
	    
	    @Then("^user should see Contact page$")
	    public void user_should_see_Contact_page() throws Throwable {
	    	String expectedTitle = "Contact the physIQ Team";
	    	Assert.assertTrue(contactPage.getTitle().contains(expectedTitle));
	    }
	    
	    @And("^verify main office address details$")
	    public void verify_main_office_address_details() throws Throwable {
	     	String expectedAddress = "200 W. Jackson Blvd\nSuite 550\nChicago, Illinois\n60606\nUnited States\nPhone: 800.516.7902\nE-mail: info@physIQ.com";
	    	Assert.assertEquals(expectedAddress, contactPage.mainOfficeAddressDetails());
	    }
	    
	    @And("^verify Naperville office address details$")
	    public void verify_Naperville_office_address_details() throws Throwable {
	    	String expectedAddress = "300 E. 5th Avenue\nSuite 105\nNaperville, Illinois\n60563\nUnited States";
	    	Assert.assertEquals(expectedAddress, contactPage.napervilleOfficeAddressDetails());
	    }
	    
	    @And("^fill out the contact form$")
	    public void fill_out_the_contact_form() throws Throwable {
	    	testBase.getDriver().switchTo().frame(contactPage.formForContactDetails());
			
			
			contactPage.fillInForm(contactPage.InputField("firstName"),"Rohini");
			contactPage.fillInForm(contactPage.InputField("lastName"),"Gund");
			contactPage.fillInForm(contactPage.InputField("emailAddress"),"rohinimgund@gmail.com");
			contactPage.fillInForm(contactPage.InputField("title"),"SDET");
			contactPage.fillInForm(contactPage.InputField("companyName"),"BIOVIA");
			contactPage.fillInForm(contactPage.InputField("phoneNumber"),"9876543210");
			contactPage.fillInForm(contactPage.InputTextAreaField("comments"), "Test fill form functionality in Contact Us Page");			
	    
			testBase.getDriver().switchTo().defaultContent();
	    }
	    
	    @And("^take screenshot of filled contact form before submitting it$")
	    public void take_screenshot_of_filled_contact_form_before_submitting_it() throws Throwable {
	    	testBase.takeSnapShotOfForm(testBase.getDriver(), "src/test/resources/screenshots/ContactForm.png") ; 
			
	    }
	    
	    @Then("^click on Open Positions Link$")
	    public void click_on_Open_Positions_Link() throws Throwable {
	    	contactPage.viewOpenPositions().click();
	    }
	    
	    @Then("^close Browser$")
	    public void close_Browser() throws Throwable {
	    	testBase.getDriver().quit();
	    }
	    
}
